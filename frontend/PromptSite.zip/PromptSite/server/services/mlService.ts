import { storage } from "../storage";

export class MLService {
  async analyzeCustomerBehavior(vendorId: number) {
    try {
      // Get orders data for the vendor
      const orders = await storage.getOrdersByVendor(vendorId);
      
      // Group orders by customer phone numbers
      const customerPatterns = new Map();
      
      for (const order of orders) {
        // In a real implementation, you would get phone number from customer data
        // For now, we'll simulate the analysis
        const customerId = order.customerId;
        
        if (!customerPatterns.has(customerId)) {
          customerPatterns.set(customerId, {
            customerId,
            totalOrders: 0,
            resellTimeOrders: 0,
            regularOrders: 0,
            orderTimes: [],
            lastOrderTime: null,
          });
        }
        
        const pattern = customerPatterns.get(customerId);
        pattern.totalOrders++;
        pattern.orderTimes.push(order.orderTime);
        pattern.lastOrderTime = order.orderTime;
        
        // Simple heuristic: orders after 8 PM are considered "resell time"
        const orderHour = new Date(order.orderTime!).getHours();
        if (orderHour >= 20) {
          pattern.resellTimeOrders++;
        } else {
          pattern.regularOrders++;
        }
      }
      
      // Classify customers and detect misuse
      const results = {
        classifications: {
          regular: 0,
          resellOnly: 0,
          mixed: 0,
          suspicious: 0,
        },
        misuseAlerts: [],
      };
      
      for (const [customerId, pattern] of customerPatterns) {
        const resellRatio = pattern.resellTimeOrders / pattern.totalOrders;
        let classification = 'regular';
        let riskScore = 0;
        
        if (resellRatio > 0.8) {
          classification = 'resell_only';
          riskScore = 70;
        } else if (resellRatio > 0.4) {
          classification = 'mixed';
          riskScore = 40;
        } else {
          classification = 'regular';
          riskScore = 10;
        }
        
        // Check for suspicious patterns
        if (pattern.totalOrders > 10 && resellRatio > 0.9) {
          classification = 'suspicious';
          riskScore = 95;
          
          // Create misuse alert
          await storage.createMisuseAlert({
            customerId: pattern.customerId,
            vendorId,
            alertType: 'reselling_pattern',
            description: `Customer shows consistent reselling pattern with ${pattern.totalOrders} orders, ${Math.round(resellRatio * 100)}% during resell time`,
            riskLevel: 'high',
          });
          
          results.misuseAlerts.push({
            customerId: pattern.customerId,
            alertType: 'reselling_pattern',
            riskLevel: 'high',
            pattern: pattern,
          });
        }
        
        // Check for high frequency orders (potential bulk buying for resale)
        const recentOrders = pattern.orderTimes.filter(time => {
          const daysSince = (Date.now() - new Date(time).getTime()) / (1000 * 60 * 60 * 24);
          return daysSince <= 7;
        });
        
        if (recentOrders.length > 15) {
          classification = 'suspicious';
          riskScore = Math.max(riskScore, 90);
          
          await storage.createMisuseAlert({
            customerId: pattern.customerId,
            vendorId,
            alertType: 'high_frequency',
            description: `Extremely high order frequency: ${recentOrders.length} orders in last 7 days`,
            riskLevel: 'critical',
          });
          
          results.misuseAlerts.push({
            customerId: pattern.customerId,
            alertType: 'high_frequency',
            riskLevel: 'critical',
            recentOrderCount: recentOrders.length,
          });
        }
        
        // Update customer behavior record
        await storage.updateCustomerBehavior(pattern.customerId, {
          orderFrequency: pattern.totalOrders,
          resellTimeOnlyOrders: pattern.resellTimeOrders,
          regularOrders: pattern.regularOrders,
          classification: classification as any,
          riskScore: riskScore.toString(),
          lastAnalyzed: new Date(),
        });
        
        results.classifications[classification as keyof typeof results.classifications]++;
      }
      
      return results;
    } catch (error) {
      console.error('Customer behavior analysis error:', error);
      throw new Error('Failed to analyze customer behavior');
    }
  }
  
  async generateDemandForecasts(vendorId: number) {
    try {
      // Get historical order data
      const orders = await storage.getOrdersByVendor(vendorId);
      
      // Sample food items for forecasting
      const foodItems = ['Biryani', 'Samosas', 'Curry', 'Dal', 'Roti'];
      const forecasts = [];
      
      for (const item of foodItems) {
        // Simple demand prediction based on historical data and factors
        const baselineOrders = Math.floor(Math.random() * 20) + 10; // 10-30 baseline
        
        // Factor in day of week (weekends higher demand)
        const today = new Date();
        const tomorrow = new Date(today);
        tomorrow.setDate(tomorrow.getDate() + 1);
        const dayOfWeek = tomorrow.getDay();
        const weekendMultiplier = (dayOfWeek === 0 || dayOfWeek === 6) ? 1.3 : 1.0;
        
        // Factor in weather (rainy days increase comfort food demand)
        const weatherMultiplier = Math.random() > 0.7 ? 1.2 : 1.0; // 30% chance of weather impact
        
        // Factor in festivals/events
        const eventMultiplier = Math.random() > 0.9 ? 1.5 : 1.0; // 10% chance of special event
        
        const predictedQuantity = Math.round(baselineOrders * weekendMultiplier * weatherMultiplier * eventMultiplier);
        
        // Calculate confidence based on historical data availability
        const confidence = Math.min(95, 60 + (orders.length / 10)); // Higher confidence with more data
        
        const factors = {
          baseline: baselineOrders,
          weekendMultiplier,
          weatherMultiplier,
          eventMultiplier,
          historicalDataPoints: orders.length,
        };
        
        const forecast = await storage.createDemandForecast({
          vendorId,
          foodItemName: item,
          predictedQuantity,
          confidence: confidence.toString(),
          forecastDate: tomorrow,
          factors,
        });
        
        forecasts.push(forecast);
      }
      
      return forecasts;
    } catch (error) {
      console.error('Demand forecasting error:', error);
      throw new Error('Failed to generate demand forecasts');
    }
  }
}

export const mlService = new MLService();
