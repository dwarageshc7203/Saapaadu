import { storage } from "../storage";

export class AnalyticsService {
  async getSalesChartData(vendorId: number) {
    try {
      const orders = await storage.getOrdersByVendor(vendorId);
      
      // Get last 30 days of data
      const thirtyDaysAgo = new Date();
      thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
      
      const recentOrders = orders.filter(order => 
        order.orderTime && new Date(order.orderTime) >= thirtyDaysAgo
      );
      
      // Group by day
      const dailySales = new Map();
      
      for (const order of recentOrders) {
        const date = new Date(order.orderTime!).toISOString().split('T')[0];
        if (!dailySales.has(date)) {
          dailySales.set(date, { date, revenue: 0, orders: 0 });
        }
        
        const dayData = dailySales.get(date);
        dayData.revenue += parseFloat(order.totalAmount);
        dayData.orders += 1;
      }
      
      // Convert to array and sort by date
      const chartData = Array.from(dailySales.values())
        .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
      
      return chartData;
    } catch (error) {
      console.error('Sales chart data error:', error);
      throw new Error('Failed to get sales chart data');
    }
  }
  
  async getWasteChartData(vendorId: number) {
    try {
      const wasteMetrics = await storage.getWasteMetrics(vendorId);
      
      const chartData = wasteMetrics.map(metric => ({
        date: metric.date,
        foodSaved: parseFloat(metric.foodSaved),
        foodWasted: parseFloat(metric.foodWasted),
        wasteReduction: parseFloat(metric.wasteReduction),
      }));
      
      return chartData;
    } catch (error) {
      console.error('Waste chart data error:', error);
      throw new Error('Failed to get waste chart data');
    }
  }
  
  async getCustomerSavingsData(customerId: number) {
    try {
      const orders = await storage.getOrdersByCustomer(customerId);
      
      // Group by month
      const monthlySavings = new Map();
      
      for (const order of orders) {
        if (!order.orderTime) continue;
        
        const date = new Date(order.orderTime);
        const monthKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
        
        if (!monthlySavings.has(monthKey)) {
          monthlySavings.set(monthKey, { month: monthKey, savings: 0, orders: 0 });
        }
        
        const monthData = monthlySavings.get(monthKey);
        monthData.savings += parseFloat(order.savings);
        monthData.orders += 1;
      }
      
      // Convert to array and sort by month
      const chartData = Array.from(monthlySavings.values())
        .sort((a, b) => a.month.localeCompare(b.month));
      
      return chartData;
    } catch (error) {
      console.error('Customer savings data error:', error);
      throw new Error('Failed to get customer savings data');
    }
  }
}

export const analyticsService = new AnalyticsService();
