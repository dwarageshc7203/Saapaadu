import {
  users,
  vendors,
  customers,
  orders,
  customerBehavior,
  misuseAlerts,
  demandForecasts,
  wasteMetrics,
  type User,
  type InsertUser,
  type Vendor,
  type InsertVendor,
  type Customer,
  type InsertCustomer,
  type Order,
  type InsertOrder,
  type MisuseAlert,
  type InsertMisuseAlert,
  type DemandForecast,
  type InsertDemandForecast,
  type CustomerBehavior,
  type WasteMetric,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, gte, sql, count } from "drizzle-orm";

export interface IStorage {
  // User management
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Vendor management
  getVendor(id: number): Promise<Vendor | undefined>;
  getVendorByUserId(userId: number): Promise<Vendor | undefined>;
  createVendor(vendor: InsertVendor): Promise<Vendor>;
  
  // Customer management
  getCustomer(id: number): Promise<Customer | undefined>;
  getCustomerByUserId(userId: number): Promise<Customer | undefined>;
  createCustomer(customer: InsertCustomer): Promise<Customer>;
  
  // Analytics
  getVendorAnalytics(vendorId: number): Promise<any>;
  getCustomerAnalytics(customerId: number): Promise<any>;
  
  // Orders
  getOrdersByCustomer(customerId: number): Promise<Order[]>;
  getOrdersByVendor(vendorId: number): Promise<Order[]>;
  createOrder(order: InsertOrder): Promise<Order>;
  
  // Misuse detection
  getMisuseAlerts(vendorId: number): Promise<MisuseAlert[]>;
  createMisuseAlert(alert: InsertMisuseAlert): Promise<MisuseAlert>;
  updateMisuseAlertStatus(id: number, status: string, actionTaken?: string): Promise<void>;
  
  // Demand forecasting
  getDemandForecasts(vendorId: number): Promise<DemandForecast[]>;
  createDemandForecast(forecast: InsertDemandForecast): Promise<DemandForecast>;
  
  // Customer behavior
  getCustomerBehavior(customerId: number): Promise<CustomerBehavior | undefined>;
  updateCustomerBehavior(customerId: number, behavior: Partial<CustomerBehavior>): Promise<void>;
  
  // Waste metrics
  getWasteMetrics(vendorId: number): Promise<WasteMetric[]>;
  createWasteMetric(metric: Omit<WasteMetric, 'id'>): Promise<WasteMetric>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async getVendor(id: number): Promise<Vendor | undefined> {
    const [vendor] = await db.select().from(vendors).where(eq(vendors.id, id));
    return vendor || undefined;
  }

  async getVendorByUserId(userId: number): Promise<Vendor | undefined> {
    const [vendor] = await db.select().from(vendors).where(eq(vendors.userId, userId));
    return vendor || undefined;
  }

  async createVendor(insertVendor: InsertVendor): Promise<Vendor> {
    const [vendor] = await db
      .insert(vendors)
      .values(insertVendor)
      .returning();
    return vendor;
  }

  async getCustomer(id: number): Promise<Customer | undefined> {
    const [customer] = await db.select().from(customers).where(eq(customers.id, id));
    return customer || undefined;
  }

  async getCustomerByUserId(userId: number): Promise<Customer | undefined> {
    const [customer] = await db.select().from(customers).where(eq(customers.userId, userId));
    return customer || undefined;
  }

  async createCustomer(insertCustomer: InsertCustomer): Promise<Customer> {
    const [customer] = await db
      .insert(customers)
      .values(insertCustomer)
      .returning();
    return customer;
  }

  async getVendorAnalytics(vendorId: number): Promise<any> {
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

    // Get total revenue
    const [revenueResult] = await db
      .select({
        totalRevenue: sql<number>`sum(${orders.totalAmount})::numeric`,
        orderCount: count(orders.id)
      })
      .from(orders)
      .where(and(
        eq(orders.vendorId, vendorId),
        gte(orders.orderTime, thirtyDaysAgo)
      ));

    // Get waste metrics
    const [wasteResult] = await db
      .select({
        totalFoodSaved: sql<number>`sum(${wasteMetrics.foodSaved})::numeric`,
        totalWasteReduction: sql<number>`avg(${wasteMetrics.wasteReduction})::numeric`,
        totalCo2Saved: sql<number>`sum(${wasteMetrics.co2Saved})::numeric`
      })
      .from(wasteMetrics)
      .where(and(
        eq(wasteMetrics.vendorId, vendorId),
        gte(wasteMetrics.date, thirtyDaysAgo)
      ));

    // Get active customers count
    const [customerResult] = await db
      .select({
        activeCustomers: sql<number>`count(distinct ${orders.customerId})::numeric`
      })
      .from(orders)
      .where(and(
        eq(orders.vendorId, vendorId),
        gte(orders.orderTime, thirtyDaysAgo)
      ));

    // Get misuse alerts count
    const [alertResult] = await db
      .select({
        misuseAlerts: count(misuseAlerts.id)
      })
      .from(misuseAlerts)
      .where(and(
        eq(misuseAlerts.vendorId, vendorId),
        eq(misuseAlerts.status, 'active')
      ));

    return {
      totalRevenue: revenueResult?.totalRevenue || 0,
      orderCount: revenueResult?.orderCount || 0,
      foodSaved: wasteResult?.totalFoodSaved || 0,
      wasteReduction: wasteResult?.totalWasteReduction || 0,
      co2Saved: wasteResult?.totalCo2Saved || 0,
      activeCustomers: customerResult?.activeCustomers || 0,
      misuseAlerts: alertResult?.misuseAlerts || 0,
    };
  }

  async getCustomerAnalytics(customerId: number): Promise<any> {
    // Get customer orders and savings
    const customerOrders = await db
      .select({
        totalOrders: count(orders.id),
        totalSavings: sql<number>`sum(${orders.savings})::numeric`,
        totalOriginalAmount: sql<number>`sum(${orders.originalAmount})::numeric`,
        totalPaid: sql<number>`sum(${orders.totalAmount})::numeric`
      })
      .from(orders)
      .where(eq(orders.customerId, customerId));

    // Calculate environmental impact (estimate based on food rescued)
    const avgFoodPerOrder = 0.5; // kg
    const co2PerKg = 2.87; // kg CO2 per kg food
    const totalOrders = customerOrders[0]?.totalOrders || 0;
    const foodRescued = totalOrders * avgFoodPerOrder;
    const co2Reduced = foodRescued * co2PerKg;

    return {
      totalOrders: totalOrders,
      totalSavings: customerOrders[0]?.totalSavings || 0,
      totalOriginalAmount: customerOrders[0]?.totalOriginalAmount || 0,
      totalPaid: customerOrders[0]?.totalPaid || 0,
      foodRescued: foodRescued,
      co2Reduced: co2Reduced,
    };
  }

  async getOrdersByCustomer(customerId: number): Promise<Order[]> {
    return await db
      .select()
      .from(orders)
      .where(eq(orders.customerId, customerId))
      .orderBy(desc(orders.orderTime));
  }

  async getOrdersByVendor(vendorId: number): Promise<Order[]> {
    return await db
      .select()
      .from(orders)
      .where(eq(orders.vendorId, vendorId))
      .orderBy(desc(orders.orderTime));
  }

  async createOrder(insertOrder: InsertOrder): Promise<Order> {
    const [order] = await db
      .insert(orders)
      .values(insertOrder)
      .returning();
    return order;
  }

  async getMisuseAlerts(vendorId: number): Promise<MisuseAlert[]> {
    return await db
      .select()
      .from(misuseAlerts)
      .where(eq(misuseAlerts.vendorId, vendorId))
      .orderBy(desc(misuseAlerts.detectedAt));
  }

  async createMisuseAlert(insertAlert: InsertMisuseAlert): Promise<MisuseAlert> {
    const [alert] = await db
      .insert(misuseAlerts)
      .values(insertAlert)
      .returning();
    return alert;
  }

  async updateMisuseAlertStatus(id: number, status: string, actionTaken?: string): Promise<void> {
    await db
      .update(misuseAlerts)
      .set({
        status,
        actionTaken,
        reviewedAt: new Date(),
      })
      .where(eq(misuseAlerts.id, id));
  }

  async getDemandForecasts(vendorId: number): Promise<DemandForecast[]> {
    return await db
      .select()
      .from(demandForecasts)
      .where(eq(demandForecasts.vendorId, vendorId))
      .orderBy(desc(demandForecasts.forecastDate));
  }

  async createDemandForecast(insertForecast: InsertDemandForecast): Promise<DemandForecast> {
    const [forecast] = await db
      .insert(demandForecasts)
      .values(insertForecast)
      .returning();
    return forecast;
  }

  async getCustomerBehavior(customerId: number): Promise<CustomerBehavior | undefined> {
    const [behavior] = await db
      .select()
      .from(customerBehavior)
      .where(eq(customerBehavior.customerId, customerId));
    return behavior || undefined;
  }

  async updateCustomerBehavior(customerId: number, behavior: Partial<CustomerBehavior>): Promise<void> {
    await db
      .update(customerBehavior)
      .set(behavior)
      .where(eq(customerBehavior.customerId, customerId));
  }

  async getWasteMetrics(vendorId: number): Promise<WasteMetric[]> {
    return await db
      .select()
      .from(wasteMetrics)
      .where(eq(wasteMetrics.vendorId, vendorId))
      .orderBy(desc(wasteMetrics.date));
  }

  async createWasteMetric(metric: Omit<WasteMetric, 'id'>): Promise<WasteMetric> {
    const [wasteMetric] = await db
      .insert(wasteMetrics)
      .values(metric)
      .returning();
    return wasteMetric;
  }
}

export const storage = new DatabaseStorage();
