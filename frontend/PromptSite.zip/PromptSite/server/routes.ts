import type { Express } from "express";
import { createServer, type Server } from "http";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { storage } from "./storage";
import { insertUserSchema, insertVendorSchema, insertCustomerSchema } from "@shared/schema";
import { mlService } from "./services/mlService";
import { analyticsService } from "./services/analyticsService";

const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key";

interface AuthRequest extends Request {
  user?: any;
}

// Middleware to verify JWT token
const authenticateToken = async (req: any, res: any, next: any) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ message: 'Access token required' });
  }

  try {
    const decoded = jwt.verify(token, JWT_SECRET) as any;
    const user = await storage.getUser(decoded.userId);
    if (!user) {
      return res.status(401).json({ message: 'Invalid token' });
    }
    req.user = user;
    next();
  } catch (error) {
    return res.status(403).json({ message: 'Invalid token' });
  }
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Authentication routes
  app.post("/api/auth/register", async (req, res) => {
    try {
      const { username, email, password, role, name, phone, restaurantName, address } = req.body;

      // Validate input
      const userData = insertUserSchema.parse({
        username,
        email,
        password: await bcrypt.hash(password, 10),
        role,
        name,
        phone,
      });

      // Create user
      const user = await storage.createUser(userData);

      // Create role-specific profile
      if (role === 'vendor' && restaurantName && address) {
        await storage.createVendor({
          userId: user.id,
          restaurantName,
          address,
        });
      } else if (role === 'customer') {
        await storage.createCustomer({
          userId: user.id,
        });
      }

      // Generate JWT token
      const token = jwt.sign({ userId: user.id }, JWT_SECRET, { expiresIn: '24h' });

      res.json({
        token,
        user: { id: user.id, username: user.username, email: user.email, role: user.role, name: user.name }
      });
    } catch (error) {
      console.error('Registration error:', error);
      res.status(400).json({ message: 'Registration failed' });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const { email, password } = req.body;

      const user = await storage.getUserByEmail(email);
      if (!user) {
        return res.status(401).json({ message: 'Invalid credentials' });
      }

      const isValidPassword = await bcrypt.compare(password, user.password);
      if (!isValidPassword) {
        return res.status(401).json({ message: 'Invalid credentials' });
      }

      const token = jwt.sign({ userId: user.id }, JWT_SECRET, { expiresIn: '24h' });

      res.json({
        token,
        user: { id: user.id, username: user.username, email: user.email, role: user.role, name: user.name }
      });
    } catch (error) {
      console.error('Login error:', error);
      res.status(500).json({ message: 'Login failed' });
    }
  });

  // User profile routes
  app.get("/api/user/profile", authenticateToken, async (req: any, res) => {
    try {
      const user = req.user;
      let profile = null;

      if (user.role === 'vendor') {
        profile = await storage.getVendorByUserId(user.id);
      } else if (user.role === 'customer') {
        profile = await storage.getCustomerByUserId(user.id);
      }

      res.json({ user, profile });
    } catch (error) {
      console.error('Profile fetch error:', error);
      res.status(500).json({ message: 'Failed to fetch profile' });
    }
  });

  // Vendor analytics routes
  app.get("/api/vendor/analytics", authenticateToken, async (req: any, res) => {
    try {
      if (req.user.role !== 'vendor') {
        return res.status(403).json({ message: 'Access denied' });
      }

      const vendor = await storage.getVendorByUserId(req.user.id);
      if (!vendor) {
        return res.status(404).json({ message: 'Vendor profile not found' });
      }

      const analytics = await storage.getVendorAnalytics(vendor.id);
      res.json(analytics);
    } catch (error) {
      console.error('Vendor analytics error:', error);
      res.status(500).json({ message: 'Failed to fetch analytics' });
    }
  });

  // Customer analytics routes
  app.get("/api/customer/analytics", authenticateToken, async (req: any, res) => {
    try {
      if (req.user.role !== 'customer') {
        return res.status(403).json({ message: 'Access denied' });
      }

      const customer = await storage.getCustomerByUserId(req.user.id);
      if (!customer) {
        return res.status(404).json({ message: 'Customer profile not found' });
      }

      const analytics = await storage.getCustomerAnalytics(customer.id);
      res.json(analytics);
    } catch (error) {
      console.error('Customer analytics error:', error);
      res.status(500).json({ message: 'Failed to fetch analytics' });
    }
  });

  // Misuse detection routes
  app.get("/api/vendor/misuse-alerts", authenticateToken, async (req: any, res) => {
    try {
      if (req.user.role !== 'vendor') {
        return res.status(403).json({ message: 'Access denied' });
      }

      const vendor = await storage.getVendorByUserId(req.user.id);
      if (!vendor) {
        return res.status(404).json({ message: 'Vendor profile not found' });
      }

      const alerts = await storage.getMisuseAlerts(vendor.id);
      res.json(alerts);
    } catch (error) {
      console.error('Misuse alerts error:', error);
      res.status(500).json({ message: 'Failed to fetch misuse alerts' });
    }
  });

  app.post("/api/vendor/misuse-alerts/:id/action", authenticateToken, async (req: any, res) => {
    try {
      if (req.user.role !== 'vendor') {
        return res.status(403).json({ message: 'Access denied' });
      }

      const { id } = req.params;
      const { action, status } = req.body;

      await storage.updateMisuseAlertStatus(parseInt(id), status, action);
      res.json({ message: 'Alert updated successfully' });
    } catch (error) {
      console.error('Misuse alert action error:', error);
      res.status(500).json({ message: 'Failed to update alert' });
    }
  });

  // Demand forecasting routes
  app.get("/api/vendor/demand-forecasts", authenticateToken, async (req: any, res) => {
    try {
      if (req.user.role !== 'vendor') {
        return res.status(403).json({ message: 'Access denied' });
      }

      const vendor = await storage.getVendorByUserId(req.user.id);
      if (!vendor) {
        return res.status(404).json({ message: 'Vendor profile not found' });
      }

      const forecasts = await storage.getDemandForecasts(vendor.id);
      res.json(forecasts);
    } catch (error) {
      console.error('Demand forecasts error:', error);
      res.status(500).json({ message: 'Failed to fetch demand forecasts' });
    }
  });

  app.post("/api/vendor/generate-forecasts", authenticateToken, async (req: any, res) => {
    try {
      if (req.user.role !== 'vendor') {
        return res.status(403).json({ message: 'Access denied' });
      }

      const vendor = await storage.getVendorByUserId(req.user.id);
      if (!vendor) {
        return res.status(404).json({ message: 'Vendor profile not found' });
      }

      const forecasts = await mlService.generateDemandForecasts(vendor.id);
      res.json(forecasts);
    } catch (error) {
      console.error('Generate forecasts error:', error);
      res.status(500).json({ message: 'Failed to generate forecasts' });
    }
  });

  // ML analysis routes
  app.post("/api/ml/analyze-customer-behavior", authenticateToken, async (req: any, res) => {
    try {
      if (req.user.role !== 'vendor') {
        return res.status(403).json({ message: 'Access denied' });
      }

      const vendor = await storage.getVendorByUserId(req.user.id);
      if (!vendor) {
        return res.status(404).json({ message: 'Vendor profile not found' });
      }

      const analysis = await mlService.analyzeCustomerBehavior(vendor.id);
      res.json(analysis);
    } catch (error) {
      console.error('Customer behavior analysis error:', error);
      res.status(500).json({ message: 'Failed to analyze customer behavior' });
    }
  });

  // Sales chart data
  app.get("/api/vendor/sales-data", authenticateToken, async (req: any, res) => {
    try {
      if (req.user.role !== 'vendor') {
        return res.status(403).json({ message: 'Access denied' });
      }

      const vendor = await storage.getVendorByUserId(req.user.id);
      if (!vendor) {
        return res.status(404).json({ message: 'Vendor profile not found' });
      }

      const salesData = await analyticsService.getSalesChartData(vendor.id);
      res.json(salesData);
    } catch (error) {
      console.error('Sales data error:', error);
      res.status(500).json({ message: 'Failed to fetch sales data' });
    }
  });

  // Customer orders
  app.get("/api/customer/orders", authenticateToken, async (req: any, res) => {
    try {
      if (req.user.role !== 'customer') {
        return res.status(403).json({ message: 'Access denied' });
      }

      const customer = await storage.getCustomerByUserId(req.user.id);
      if (!customer) {
        return res.status(404).json({ message: 'Customer profile not found' });
      }

      const orders = await storage.getOrdersByCustomer(customer.id);
      res.json(orders);
    } catch (error) {
      console.error('Customer orders error:', error);
      res.status(500).json({ message: 'Failed to fetch orders' });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
