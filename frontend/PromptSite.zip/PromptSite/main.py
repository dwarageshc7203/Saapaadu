import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import seaborn as sns
import matplotlib.pyplot as plt
from datetime import datetime, timedelta
import json
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import classification_report, accuracy_score
import warnings
warnings.filterwarnings('ignore')

# Page configuration
st.set_page_config(
    page_title="Saapaadu Analytics Platform",
    page_icon="🍽️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for better styling
st.markdown("""
<style>
    .main-header {
        font-size: 2.5rem;
        color: #2E8B57;
        text-align: center;
        margin-bottom: 2rem;
        font-weight: bold;
    }
    .card {
        background-color: #f8f9fa;
        padding: 1.5rem;
        border-radius: 10px;
        border: 1px solid #e9ecef;
        margin-bottom: 1rem;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    .metric-card {
        text-align: center;
        padding: 1rem;
    }
    .waste-reduction-card {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        padding: 2rem;
        border-radius: 15px;
        margin: 1rem 0;
    }
    .environmental-impact {
        background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%);
        color: white;
        padding: 1.5rem;
        border-radius: 10px;
        margin: 1rem 0;
    }
    .warning-card {
        background-color: #fff3cd;
        border: 1px solid #ffeaa7;
        color: #856404;
        padding: 1rem;
        border-radius: 5px;
        margin: 1rem 0;
    }
    .success-card {
        background-color: #d1e7dd;
        border: 1px solid #badbcc;
        color: #0f5132;
        padding: 1rem;
        border-radius: 5px;
        margin: 1rem 0;
    }
</style>
""", unsafe_allow_html=True)

# Initialize session state
if 'authenticated' not in st.session_state:
    st.session_state.authenticated = False
    st.session_state.user_role = None
    st.session_state.username = None

# Data generation and ML models
@st.cache_data
def generate_sample_data():
    """Generate comprehensive sample data for the platform"""
    
    # Generate customer data
    np.random.seed(42)
    customers = []
    phone_numbers = [f"+91{np.random.randint(7000000000, 9999999999)}" for _ in range(1000)]
    
    for i, phone in enumerate(phone_numbers):
        customer_type = np.random.choice(['regular', 'reselling_only', 'mixed'], p=[0.6, 0.2, 0.2])
        
        if customer_type == 'regular':
            reselling_orders = np.random.randint(0, 3)
            regular_orders = np.random.randint(5, 20)
        elif customer_type == 'reselling_only':
            reselling_orders = np.random.randint(8, 25)
            regular_orders = np.random.randint(0, 2)
        else:  # mixed
            reselling_orders = np.random.randint(3, 10)
            regular_orders = np.random.randint(3, 15)
        
        customers.append({
            'customer_id': f'CUST_{i+1:04d}',
            'phone_number': phone,
            'total_orders': regular_orders + reselling_orders,
            'reselling_orders': reselling_orders,
            'regular_orders': regular_orders,
            'reselling_frequency': reselling_orders / (regular_orders + reselling_orders + 1),
            'customer_type': customer_type,
            'is_misusing': customer_type == 'reselling_only' and reselling_orders > 10,
            'total_spent': (regular_orders * 150) + (reselling_orders * 75),
            'money_saved': reselling_orders * 75,
            'food_saved_kg': (regular_orders + reselling_orders) * 0.5,
            'join_date': datetime.now() - timedelta(days=np.random.randint(30, 365)),
            'last_order_date': datetime.now() - timedelta(days=np.random.randint(1, 30))
        })
    
    # Generate vendor sales data
    vendors = []
    for i in range(50):
        vendor_id = f'VEND_{i+1:03d}'
        daily_sales = []
        
        # Generate 30 days of sales data
        for day in range(30):
            date = datetime.now() - timedelta(days=30-day)
            day_of_week = date.weekday()
            
            # Weekend boost
            base_sales = 50 if day_of_week < 5 else 80
            weather_factor = np.random.uniform(0.7, 1.3)
            event_factor = np.random.choice([1.0, 1.5, 2.0], p=[0.8, 0.15, 0.05])
            
            prepared = int(base_sales * weather_factor * event_factor)
            sold_regular = int(prepared * np.random.uniform(0.6, 0.9))
            sold_reselling = int((prepared - sold_regular) * np.random.uniform(0.7, 0.95))
            wasted = prepared - sold_regular - sold_reselling
            
            daily_sales.append({
                'vendor_id': vendor_id,
                'date': date,
                'day_of_week': day_of_week,
                'prepared_quantity': prepared,
                'sold_regular': sold_regular,
                'sold_reselling': sold_reselling,
                'total_sold': sold_regular + sold_reselling,
                'wasted': max(0, wasted),
                'revenue': (sold_regular * 150) + (sold_reselling * 75),
                'food_saved': sold_reselling,
                'weather': np.random.choice(['sunny', 'rainy', 'cloudy']),
                'has_event': event_factor > 1.0
            })
        
        vendors.extend(daily_sales)
    
    return pd.DataFrame(customers), pd.DataFrame(vendors)

@st.cache_resource
def train_ml_models(customer_df, vendor_df):
    """Train ML models for customer classification and demand prediction"""
    
    # Customer Behavior Classification Model
    customer_features = customer_df[['total_orders', 'reselling_orders', 'regular_orders', 'reselling_frequency']].copy()
    customer_labels = customer_df['is_misusing']
    
    X_train, X_test, y_train, y_test = train_test_split(
        customer_features, customer_labels, test_size=0.2, random_state=42
    )
    
    customer_classifier = RandomForestClassifier(n_estimators=100, random_state=42)
    customer_classifier.fit(X_train, y_train)
    
    # Food Demand Prediction Model
    vendor_features = vendor_df.copy()
    vendor_features['weather_encoded'] = LabelEncoder().fit_transform(vendor_features['weather'])
    vendor_features['has_event'] = vendor_features['has_event'].astype(int)
    
    demand_features = vendor_features[['day_of_week', 'weather_encoded', 'has_event']].copy()
    demand_labels = vendor_features['prepared_quantity']
    
    X_demand_train, X_demand_test, y_demand_train, y_demand_test = train_test_split(
        demand_features, demand_labels, test_size=0.2, random_state=42
    )
    
    demand_predictor = RandomForestRegressor(n_estimators=100, random_state=42)
    demand_predictor.fit(X_demand_train, y_demand_train)
    
    return customer_classifier, demand_predictor

def login_form():
    """Authentication form"""
    st.markdown('<h1 class="main-header">🍽️ Saapaadu Analytics Platform</h1>', unsafe_allow_html=True)
    
    with st.form("login_form"):
        st.subheader("Login to Access Analytics")
        username = st.text_input("Username")
        password = st.text_input("Password", type="password")
        role = st.selectbox("Select Role", ["vendor", "customer"])
        
        if st.form_submit_button("Login"):
            # Simple authentication (in real app, this would check against database)
            if username and password:
                st.session_state.authenticated = True
                st.session_state.user_role = role
                st.session_state.username = username
                st.rerun()
            else:
                st.error("Please enter both username and password")



def vendor_dashboard(customer_df, vendor_df, customer_classifier, demand_predictor):
    """Vendor analytics dashboard"""
    st.markdown('<h1 class="main-header">📊 Vendor Analytics Dashboard</h1>', unsafe_allow_html=True)
    
    # Vendor selection
    vendor_ids = vendor_df['vendor_id'].unique()
    selected_vendor = st.selectbox("Select Vendor", vendor_ids)
    
    vendor_data = vendor_df[vendor_df['vendor_id'] == selected_vendor].copy()
    
    # Key metrics overview
    col1, col2, col3, col4, col5 = st.columns(5)
    
    total_revenue = vendor_data['revenue'].sum()
    total_sold = vendor_data['total_sold'].sum()
    food_saved = vendor_data['food_saved'].sum()
    avg_daily_sales = vendor_data.groupby('date')['total_sold'].sum().mean()
    waste_rate = (vendor_data['wasted'].sum() / vendor_data['prepared_quantity'].sum() * 100)
    
    with col1:
        st.metric("Total Revenue", f"₹{total_revenue:,.0f}", delta="📈")
    with col2:
        st.metric("Items Sold", f"{total_sold:,}", delta=f"{avg_daily_sales:.0f}/day")
    with col3:
        st.metric("Food Saved", f"{food_saved:.0f} kg", delta="🌱")
    with col4:
        st.metric("Waste Rate", f"{waste_rate:.1f}%", delta="📉" if waste_rate < 20 else "⚠️")
    with col5:
        # Predict tomorrow's demand
        tomorrow = datetime.now() + timedelta(days=1)
        tomorrow_features = np.array([[tomorrow.weekday(), 1, 0]])  # sunny, no event
        predicted_demand = demand_predictor.predict(tomorrow_features)[0]
        st.metric("Tomorrow's Forecast", f"{predicted_demand:.0f} items", delta="🔮")
    
    # Interactive Waste Management Card (Main Feature)
    create_interactive_waste_management_card(vendor_df, selected_vendor)
    
    # Sales Analysis
    st.subheader("📈 Sales Analysis")
    
    tab1, tab2, tab3, tab4 = st.tabs(["Daily Sales", "Weekly Trends", "Monthly Summary", "Yearly Overview"])
    
    with tab1:
        daily_sales = vendor_data.groupby('date').agg({
            'revenue': 'sum',
            'total_sold': 'sum',
            'food_saved': 'sum'
        }).reset_index()
        
        fig = make_subplots(rows=2, cols=1, subplot_titles=['Daily Revenue & Sales', 'Food Saved Daily'])
        
        fig.add_trace(go.Scatter(x=daily_sales['date'], y=daily_sales['revenue'], 
                                name='Revenue (₹)', line=dict(color='blue')), row=1, col=1)
        fig.add_trace(go.Scatter(x=daily_sales['date'], y=daily_sales['total_sold'], 
                                name='Items Sold', line=dict(color='orange')), row=1, col=1)
        fig.add_trace(go.Bar(x=daily_sales['date'], y=daily_sales['food_saved'], 
                            name='Food Saved (kg)', marker_color='green'), row=2, col=1)
        
        fig.update_layout(height=600)
        st.plotly_chart(fig, use_container_width=True)
    
    with tab2:
        vendor_data['week'] = vendor_data['date'].dt.isocalendar().week
        weekly_data = vendor_data.groupby('week').agg({
            'revenue': 'sum',
            'total_sold': 'sum',
            'food_saved': 'sum',
            'wasted': 'sum'
        }).reset_index()
        
        fig = px.bar(weekly_data, x='week', y=['revenue', 'food_saved'], 
                     title='Weekly Performance', barmode='group')
        st.plotly_chart(fig, use_container_width=True)
    
    with tab3:
        vendor_data['month'] = vendor_data['date'].dt.month
        monthly_data = vendor_data.groupby('month').agg({
            'revenue': 'sum',
            'total_sold': 'sum',
            'food_saved': 'sum'
        }).reset_index()
        
        col1, col2 = st.columns(2)
        with col1:
            fig = px.pie(monthly_data, values='revenue', names='month', 
                        title='Monthly Revenue Distribution')
            st.plotly_chart(fig, use_container_width=True)
        with col2:
            fig = px.line(monthly_data, x='month', y='total_sold', 
                         title='Monthly Sales Trend')
            st.plotly_chart(fig, use_container_width=True)
    
    with tab4:
        # Yearly projection based on current data
        current_month_data = vendor_data['date'].dt.month.nunique()
        yearly_projection = {
            'Revenue': total_revenue * (12 / current_month_data),
            'Items Sold': total_sold * (12 / current_month_data),
            'Food Saved': food_saved * (12 / current_month_data)
        }
        
        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("Projected Annual Revenue", f"₹{yearly_projection['Revenue']:,.0f}")
        with col2:
            st.metric("Projected Annual Sales", f"{yearly_projection['Items Sold']:,.0f} items")
        with col3:
            st.metric("Projected Food Saved", f"{yearly_projection['Food Saved']:,.0f} kg")
    
    # Customer Insights
    st.subheader("👥 Customer Insights")
    
    # Identify misusing customers
    misusing_customers = customer_df[customer_df['is_misusing'] == True].copy()
    
    col1, col2 = st.columns([2, 1])
    
    with col1:
        # Customer behavior distribution
        customer_types = customer_df['customer_type'].value_counts()
        fig = px.pie(values=customer_types.values, names=customer_types.index,
                     title="Customer Behavior Distribution")
        st.plotly_chart(fig, use_container_width=True)
    
    with col2:
        st.markdown("**Customer Segments:**")
        for ctype, count in customer_types.items():
            percentage = (count / len(customer_df)) * 100
            st.markdown(f"- {ctype.title()}: {count} ({percentage:.1f}%)")
    
    # Misusing customers section
    if len(misusing_customers) > 0:
        st.subheader("⚠️ Customers Misusing the App")
        st.markdown('<div class="warning-card">', unsafe_allow_html=True)
        st.markdown(f"**{len(misusing_customers)} customers** detected as potentially misusing the app")
        st.markdown('</div>', unsafe_allow_html=True)
        
        # Display misusing customers with restrict option
        for idx, customer in misusing_customers.head(10).iterrows():
            col1, col2, col3, col4 = st.columns([2, 2, 2, 1])
            
            with col1:
                st.text(f"📞 {customer['phone_number']}")
            with col2:
                st.text(f"Reselling Orders: {customer['reselling_orders']}")
            with col3:
                st.text(f"Frequency: {customer['reselling_frequency']:.1%}")
            with col4:
                if st.button("🚫 Restrict", key=f"restrict_{customer['customer_id']}"):
                    st.success(f"Access restricted for {customer['phone_number']}")

def customer_dashboard(customer_df, vendor_df):
    """Customer analytics dashboard"""
    st.markdown('<h1 class="main-header">🛍️ Customer Analytics Dashboard</h1>', unsafe_allow_html=True)
    
    # Customer selection (simulate logged-in customer)
    customer_ids = customer_df['customer_id'].unique()
    selected_customer = st.selectbox("Customer Account", customer_ids)
    
    customer_data = customer_df[customer_df['customer_id'] == selected_customer].iloc[0]
    
    # Customer overview
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric("Total Orders", f"{customer_data['total_orders']}", delta="📦")
    with col2:
        st.metric("Money Saved", f"₹{customer_data['money_saved']:,.0f}", delta="💰")
    with col3:
        st.metric("Food Saved", f"{customer_data['food_saved_kg']:.1f} kg", delta="🌱")
    with col4:
        co2_saved = customer_data['food_saved_kg'] * 2.5
        st.metric("CO₂ Saved", f"{co2_saved:.1f} kg", delta="🌍")
    
    # Order History
    st.subheader("📋 Order History")
    
    # Generate order history for the customer
    order_history = []
    for i in range(customer_data['total_orders']):
        order_date = customer_data['join_date'] + timedelta(days=np.random.randint(0, 365))
        is_reselling = i < customer_data['reselling_orders']
        
        order_history.append({
            'order_id': f"ORD_{i+1:04d}",
            'date': order_date,
            'type': 'Reselling' if is_reselling else 'Regular',
            'amount': 75 if is_reselling else 150,
            'savings': 75 if is_reselling else 0,
            'food_saved': 0.5,
            'status': 'Completed'
        })
    
    order_df = pd.DataFrame(order_history)
    order_df = order_df.sort_values('date', ascending=False)
    
    # Display recent orders
    st.dataframe(order_df.head(10), use_container_width=True)
    
    # Environmental Impact
    st.subheader("🌍 Your Environmental Impact")
    
    st.markdown('<div class="environmental-impact">', unsafe_allow_html=True)
    
    col1, col2 = st.columns(2)
    
    with col1:
        # Impact metrics
        water_saved = customer_data['food_saved_kg'] * 1000
        trees_equivalent = co2_saved / 22
        
        st.metric("Water Conserved", f"{water_saved:,.0f} L", delta="🚰")
        st.metric("Equivalent Trees Planted", f"{trees_equivalent:.1f}", delta="🌳")
    
    with col2:
        # Impact visualization
        impact_data = {
            'Food Rescued (kg)': customer_data['food_saved_kg'],
            'CO₂ Reduced (kg)': co2_saved,
            'Water Saved (L)': water_saved / 1000,  # Convert to thousands
            'Money Saved (₹)': customer_data['money_saved'] / 100  # Convert to hundreds
        }
        
        fig = px.bar(
            x=list(impact_data.keys()),
            y=list(impact_data.values()),
            title="Your Positive Impact",
            color=list(impact_data.values()),
            color_continuous_scale="Greens"
        )
        st.plotly_chart(fig, use_container_width=True)
    
    st.markdown('</div>', unsafe_allow_html=True)
    
    # Savings Analysis
    st.subheader("💰 Savings Analysis")
    
    tab1, tab2 = st.tabs(["Monthly Savings", "Savings Breakdown"])
    
    with tab1:
        # Monthly savings trend
        order_df['month'] = order_df['date'].dt.to_period('M')
        monthly_savings = order_df.groupby('month')['savings'].sum().reset_index()
        monthly_savings['month_str'] = monthly_savings['month'].astype(str)
        
        fig = px.line(monthly_savings, x='month_str', y='savings', 
                      title='Monthly Savings Trend', markers=True)
        st.plotly_chart(fig, use_container_width=True)
    
    with tab2:
        # Savings by order type
        savings_by_type = order_df.groupby('type').agg({
            'savings': 'sum',
            'amount': 'sum',
            'order_id': 'count'
        }).reset_index()
        
        col1, col2 = st.columns(2)
        with col1:
            fig = px.pie(savings_by_type, values='savings', names='type',
                        title='Savings by Order Type')
            st.plotly_chart(fig, use_container_width=True)
        
        with col2:
            st.markdown("**Savings Summary:**")
            total_spent = order_df['amount'].sum()
            total_saved = order_df['savings'].sum()
            savings_rate = (total_saved / (total_spent + total_saved)) * 100
            
            st.metric("Total Spent", f"₹{total_spent:,.0f}")
            st.metric("Total Saved", f"₹{total_saved:,.0f}")
            st.metric("Savings Rate", f"{savings_rate:.1f}%")

def main():
    """Main application"""
    
    if not st.session_state.authenticated:
        login_form()
        return
    
    # Load data and models
    customer_df, vendor_df = generate_sample_data()
    customer_classifier, demand_predictor = train_ml_models(customer_df, vendor_df)
    
    # Sidebar
    st.sidebar.title(f"Welcome, {st.session_state.username}!")
    st.sidebar.markdown(f"**Role:** {st.session_state.user_role.title()}")
    
    if st.sidebar.button("🚪 Logout"):
        st.session_state.authenticated = False
        st.session_state.user_role = None
        st.session_state.username = None
        st.rerun()
    
    # Role-based dashboard
    if st.session_state.user_role == "vendor":
        vendor_dashboard(customer_df, vendor_df, customer_classifier, demand_predictor)
    else:
        customer_dashboard(customer_df, vendor_df)

if __name__ == "__main__":
    main()