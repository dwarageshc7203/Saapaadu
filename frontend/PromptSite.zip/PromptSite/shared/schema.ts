import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, decimal, boolean, timestamp, jsonb, serial } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  role: text("role", { enum: ["vendor", "customer", "admin"] }).notNull().default("customer"),
  name: text("name").notNull(),
  phone: text("phone"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").default(sql`now()`),
});

export const vendors = pgTable("vendors", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  restaurantName: text("restaurant_name").notNull(),
  address: text("address").notNull(),
  latitude: decimal("latitude", { precision: 10, scale: 8 }),
  longitude: decimal("longitude", { precision: 11, scale: 8 }),
  cuisineType: text("cuisine_type"),
  rating: decimal("rating", { precision: 2, scale: 1 }).default("0"),
  isVerified: boolean("is_verified").default(false),
});

export const customers = pgTable("customers", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  preferredCuisines: text("preferred_cuisines").array(),
  totalOrders: integer("total_orders").default(0),
  totalSavings: decimal("total_savings", { precision: 10, scale: 2 }).default("0"),
  loyaltyPoints: integer("loyalty_points").default(0),
});

export const foodItems = pgTable("food_items", {
  id: serial("id").primaryKey(),
  vendorId: integer("vendor_id").references(() => vendors.id).notNull(),
  name: text("name").notNull(),
  description: text("description"),
  category: text("category").notNull(),
  originalPrice: decimal("original_price", { precision: 8, scale: 2 }).notNull(),
  discountedPrice: decimal("discounted_price", { precision: 8, scale: 2 }).notNull(),
  quantity: integer("quantity").notNull(),
  expiryTime: timestamp("expiry_time").notNull(),
  isAvailable: boolean("is_available").default(true),
  createdAt: timestamp("created_at").default(sql`now()`),
});

export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  customerId: integer("customer_id").references(() => customers.id).notNull(),
  vendorId: integer("vendor_id").references(() => vendors.id).notNull(),
  totalAmount: decimal("total_amount", { precision: 10, scale: 2 }).notNull(),
  originalAmount: decimal("original_amount", { precision: 10, scale: 2 }).notNull(),
  savings: decimal("savings", { precision: 10, scale: 2 }).notNull(),
  status: text("status", { enum: ["pending", "confirmed", "prepared", "completed", "cancelled"] }).default("pending"),
  orderTime: timestamp("order_time").default(sql`now()`),
  pickupTime: timestamp("pickup_time"),
});

export const orderItems = pgTable("order_items", {
  id: serial("id").primaryKey(),
  orderId: integer("order_id").references(() => orders.id).notNull(),
  foodItemId: integer("food_item_id").references(() => foodItems.id).notNull(),
  quantity: integer("quantity").notNull(),
  price: decimal("price", { precision: 8, scale: 2 }).notNull(),
  originalPrice: decimal("original_price", { precision: 8, scale: 2 }).notNull(),
});

export const customerBehavior = pgTable("customer_behavior", {
  id: serial("id").primaryKey(),
  customerId: integer("customer_id").references(() => customers.id).notNull(),
  phoneNumber: text("phone_number").notNull(),
  orderFrequency: integer("order_frequency").default(0),
  resellTimeOnlyOrders: integer("resell_time_only_orders").default(0),
  regularOrders: integer("regular_orders").default(0),
  suspiciousPatterns: integer("suspicious_patterns").default(0),
  classification: text("classification", { enum: ["regular", "resell_only", "mixed", "suspicious"] }).default("regular"),
  riskScore: decimal("risk_score", { precision: 5, scale: 2 }).default("0"),
  lastAnalyzed: timestamp("last_analyzed").default(sql`now()`),
});

export const misuseAlerts = pgTable("misuse_alerts", {
  id: serial("id").primaryKey(),
  customerId: integer("customer_id").references(() => customers.id).notNull(),
  vendorId: integer("vendor_id").references(() => vendors.id).notNull(),
  alertType: text("alert_type", { enum: ["high_frequency", "reselling_pattern", "suspicious_behavior"] }).notNull(),
  description: text("description").notNull(),
  riskLevel: text("risk_level", { enum: ["low", "medium", "high", "critical"] }).notNull(),
  status: text("status", { enum: ["active", "reviewed", "resolved", "false_positive"] }).default("active"),
  detectedAt: timestamp("detected_at").default(sql`now()`),
  reviewedAt: timestamp("reviewed_at"),
  actionTaken: text("action_taken"),
});

export const demandForecasts = pgTable("demand_forecasts", {
  id: serial("id").primaryKey(),
  vendorId: integer("vendor_id").references(() => vendors.id).notNull(),
  foodItemName: text("food_item_name").notNull(),
  predictedQuantity: integer("predicted_quantity").notNull(),
  confidence: decimal("confidence", { precision: 5, scale: 2 }).notNull(),
  forecastDate: timestamp("forecast_date").notNull(),
  factors: jsonb("factors"), // weather, events, historical data
  actualQuantity: integer("actual_quantity"),
  accuracy: decimal("accuracy", { precision: 5, scale: 2 }),
  createdAt: timestamp("created_at").default(sql`now()`),
});

export const wasteMetrics = pgTable("waste_metrics", {
  id: serial("id").primaryKey(),
  vendorId: integer("vendor_id").references(() => vendors.id).notNull(),
  date: timestamp("date").notNull(),
  totalFoodPrepared: decimal("total_food_prepared", { precision: 8, scale: 2 }).notNull(),
  foodSold: decimal("food_sold", { precision: 8, scale: 2 }).notNull(),
  foodWasted: decimal("food_wasted", { precision: 8, scale: 2 }).notNull(),
  foodSaved: decimal("food_saved", { precision: 8, scale: 2 }).notNull(),
  wasteReduction: decimal("waste_reduction", { precision: 5, scale: 2 }).notNull(),
  co2Saved: decimal("co2_saved", { precision: 8, scale: 2 }).notNull(),
});

// Relations
export const usersRelations = relations(users, ({ one }) => ({
  vendor: one(vendors, {
    fields: [users.id],
    references: [vendors.userId],
  }),
  customer: one(customers, {
    fields: [users.id],
    references: [customers.userId],
  }),
}));

export const vendorsRelations = relations(vendors, ({ one, many }) => ({
  user: one(users, {
    fields: [vendors.userId],
    references: [users.id],
  }),
  foodItems: many(foodItems),
  orders: many(orders),
  wasteMetrics: many(wasteMetrics),
  demandForecasts: many(demandForecasts),
  misuseAlerts: many(misuseAlerts),
}));

export const customersRelations = relations(customers, ({ one, many }) => ({
  user: one(users, {
    fields: [customers.userId],
    references: [users.id],
  }),
  orders: many(orders),
  behavior: one(customerBehavior, {
    fields: [customers.id],
    references: [customerBehavior.customerId],
  }),
  misuseAlerts: many(misuseAlerts),
}));

export const ordersRelations = relations(orders, ({ one, many }) => ({
  customer: one(customers, {
    fields: [orders.customerId],
    references: [customers.id],
  }),
  vendor: one(vendors, {
    fields: [orders.vendorId],
    references: [vendors.id],
  }),
  items: many(orderItems),
}));

export const orderItemsRelations = relations(orderItems, ({ one }) => ({
  order: one(orders, {
    fields: [orderItems.orderId],
    references: [orders.id],
  }),
  foodItem: one(foodItems, {
    fields: [orderItems.foodItemId],
    references: [foodItems.id],
  }),
}));

// Insert Schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
});

export const insertVendorSchema = createInsertSchema(vendors).omit({
  id: true,
});

export const insertCustomerSchema = createInsertSchema(customers).omit({
  id: true,
});

export const insertOrderSchema = createInsertSchema(orders).omit({
  id: true,
  orderTime: true,
});

export const insertMisuseAlertSchema = createInsertSchema(misuseAlerts).omit({
  id: true,
  detectedAt: true,
});

export const insertDemandForecastSchema = createInsertSchema(demandForecasts).omit({
  id: true,
  createdAt: true,
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertVendor = z.infer<typeof insertVendorSchema>;
export type Vendor = typeof vendors.$inferSelect;
export type InsertCustomer = z.infer<typeof insertCustomerSchema>;
export type Customer = typeof customers.$inferSelect;
export type InsertOrder = z.infer<typeof insertOrderSchema>;
export type Order = typeof orders.$inferSelect;
export type InsertMisuseAlert = z.infer<typeof insertMisuseAlertSchema>;
export type MisuseAlert = typeof misuseAlerts.$inferSelect;
export type InsertDemandForecast = z.infer<typeof insertDemandForecastSchema>;
export type DemandForecast = typeof demandForecasts.$inferSelect;
export type CustomerBehavior = typeof customerBehavior.$inferSelect;
export type WasteMetric = typeof wasteMetrics.$inferSelect;
