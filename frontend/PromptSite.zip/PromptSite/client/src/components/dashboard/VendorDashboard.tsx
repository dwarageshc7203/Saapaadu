import { useQuery } from '@tanstack/react-query';
import { KPICard } from '@/components/ui/KPICard';
import { MisuseAlert } from '@/components/ui/MisuseAlert';
import { DemandForecast } from '@/components/ui/DemandForecast';
import { SalesChart } from '@/components/charts/SalesChart';
import { WasteChart } from '@/components/charts/WasteChart';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import {
  DollarSign,
  Recycle,
  Users,
  Shield,
  User,
  Clock,
  Shuffle,
  TrendingUp,
} from 'lucide-react';

export function VendorDashboard() {
  const { data: analytics, isLoading: analyticsLoading } = useQuery({
    queryKey: ['/api/vendor/analytics'],
  });

  const { data: misuseAlerts, isLoading: alertsLoading } = useQuery({
    queryKey: ['/api/vendor/misuse-alerts'],
  });

  if (analyticsLoading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0,
    }).format(value);
  };

  return (
    <div className="space-y-8">
      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
        <KPICard
          title="Total Revenue"
          value={formatCurrency(analytics?.totalRevenue || 0)}
          change="+12.5% from last month"
          changeType="positive"
          icon={DollarSign}
          iconColor="text-green-600"
          iconBgColor="bg-green-100"
        />
        <KPICard
          title="Food Saved"
          value={`${analytics?.foodSaved || 0} kg`}
          change="+8.3% from last month"
          changeType="positive"
          icon={Recycle}
          iconColor="text-blue-600"
          iconBgColor="bg-blue-100"
        />
        <KPICard
          title="Active Customers"
          value={analytics?.activeCustomers || 0}
          change="+15.2% from last month"
          changeType="positive"
          icon={Users}
          iconColor="text-purple-600"
          iconBgColor="bg-purple-100"
        />
        <KPICard
          title="Misuse Alerts"
          value={analytics?.misuseAlerts || 0}
          change="Requires attention"
          changeType="negative"
          icon={Shield}
          iconColor="text-red-600"
          iconBgColor="bg-red-100"
        />
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        <SalesChart />
        <WasteChart />
      </div>

      {/* Tables Row */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        {/* Customer Classifications */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Customer Classifications</CardTitle>
              <Button variant="ghost" size="sm">
                View All
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                    <User className="w-5 h-5 text-green-600" />
                  </div>
                  <div>
                    <p className="font-medium text-gray-900">Regular Buyers</p>
                    <p className="text-sm text-gray-500">127 customers</p>
                  </div>
                </div>
                <span className="text-lg font-semibold text-gray-900">73%</span>
              </div>

              <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-yellow-100 rounded-full flex items-center justify-center">
                    <Clock className="w-5 h-5 text-yellow-600" />
                  </div>
                  <div>
                    <p className="font-medium text-gray-900">Time-based Buyers</p>
                    <p className="text-sm text-gray-500">35 customers</p>
                  </div>
                </div>
                <span className="text-lg font-semibold text-gray-900">20%</span>
              </div>

              <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center">
                    <Shuffle className="w-5 h-5 text-purple-600" />
                  </div>
                  <div>
                    <p className="font-medium text-gray-900">Mixed Patterns</p>
                    <p className="text-sm text-gray-500">12 customers</p>
                  </div>
                </div>
                <span className="text-lg font-semibold text-gray-900">7%</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Misuse Detection Panel */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Misuse Detection Alerts</CardTitle>
              <span className="bg-red-100 text-red-800 text-xs px-2 py-1 rounded-full">
                {misuseAlerts?.length || 0} Active
              </span>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {alertsLoading ? (
                <div className="flex items-center justify-center h-32">
                  <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-primary"></div>
                </div>
              ) : misuseAlerts && misuseAlerts.length > 0 ? (
                misuseAlerts.slice(0, 2).map((alert: any) => (
                  <MisuseAlert key={alert.id} alert={alert} />
                ))
              ) : (
                <div className="text-center py-8 text-gray-500">
                  <Shield className="w-12 h-12 mx-auto mb-2 text-gray-300" />
                  <p>No active misuse alerts</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Demand Forecasting Panel */}
      <DemandForecast />
    </div>
  );
}
