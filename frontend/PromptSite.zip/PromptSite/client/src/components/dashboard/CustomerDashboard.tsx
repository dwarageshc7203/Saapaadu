import { useQuery } from '@tanstack/react-query';
import { KPICard } from '@/components/ui/KPICard';
import { SavingsChart } from '@/components/charts/SavingsChart';
import { ImpactChart } from '@/components/charts/ImpactChart';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  ShoppingBag,
  PiggyBank,
  Leaf,
  Globe,
} from 'lucide-react';

export function CustomerDashboard() {
  const { data: analytics, isLoading: analyticsLoading } = useQuery({
    queryKey: ['/api/customer/analytics'],
  });

  const { data: orders, isLoading: ordersLoading } = useQuery({
    queryKey: ['/api/customer/orders'],
  });

  if (analyticsLoading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0,
    }).format(value);
  };

  const mealsEquivalent = Math.round((analytics?.foodRescued || 0) * 3.8); // Assuming 1kg = ~3.8 meals

  return (
    <div className="space-y-8">
      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
        <KPICard
          title="Total Orders"
          value={analytics?.totalOrders || 0}
          change="Since joining 3 months ago"
          changeType="neutral"
          icon={ShoppingBag}
          iconColor="text-blue-600"
          iconBgColor="bg-blue-100"
        />
        <KPICard
          title="Money Saved"
          value={formatCurrency(analytics?.totalSavings || 0)}
          change="Average 40% off retail prices"
          changeType="positive"
          icon={PiggyBank}
          iconColor="text-green-600"
          iconBgColor="bg-green-100"
        />
        <KPICard
          title="Food Rescued"
          value={`${analytics?.foodRescued?.toFixed(1) || 0} kg`}
          change={`Equivalent to ${mealsEquivalent} meals`}
          changeType="positive"
          icon={Leaf}
          iconColor="text-emerald-600"
          iconBgColor="bg-emerald-100"
        />
        <KPICard
          title="CO₂ Reduced"
          value={`${analytics?.co2Reduced?.toFixed(1) || 0} kg`}
          change="Environmental impact"
          changeType="positive"
          icon={Globe}
          iconColor="text-teal-600"
          iconBgColor="bg-teal-100"
        />
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        <SavingsChart />
        <ImpactChart />
      </div>

      {/* Recent Orders Table */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Recent Orders</CardTitle>
            <Button variant="ghost" size="sm">
              View All Orders
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {ordersLoading ? (
            <div className="flex items-center justify-center h-32">
              <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-primary"></div>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-gray-200">
                    <th className="text-left py-3 px-4 font-medium text-gray-700">Date</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-700">Order ID</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-700">Retail Price</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-700">Paid</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-700">Saved</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-700">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {orders?.slice(0, 5).map((order: any) => (
                    <tr key={order.id} className="border-b border-gray-100">
                      <td className="py-4 px-4 text-sm text-gray-600">
                        {new Date(order.orderTime).toLocaleDateString()}
                      </td>
                      <td className="py-4 px-4 text-sm font-medium text-gray-900">
                        #{order.id}
                      </td>
                      <td className="py-4 px-4 text-sm text-gray-500">
                        {formatCurrency(parseFloat(order.originalAmount))}
                      </td>
                      <td className="py-4 px-4 text-sm font-medium text-gray-900">
                        {formatCurrency(parseFloat(order.totalAmount))}
                      </td>
                      <td className="py-4 px-4 text-sm font-medium text-green-600">
                        {formatCurrency(parseFloat(order.savings))}
                      </td>
                      <td className="py-4 px-4">
                        <Badge variant={order.status === 'completed' ? 'default' : 'secondary'}>
                          {order.status}
                        </Badge>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {(!orders || orders.length === 0) && (
                <div className="text-center py-8 text-gray-500">
                  <ShoppingBag className="w-12 h-12 mx-auto mb-2 text-gray-300" />
                  <p>No orders found</p>
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
