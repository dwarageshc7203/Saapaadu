import { useRole } from '@/contexts/RoleContext';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Bell, Calendar, ChevronDown } from 'lucide-react';

export function Header() {
  const { currentRole } = useRole();

  const pageTitle = currentRole === 'vendor' ? 'Vendor Overview' : 'Personal Dashboard';
  const pageSubtitle = currentRole === 'vendor' 
    ? "Monitor your restaurant's performance and impact"
    : 'Track your savings and environmental impact';

  return (
    <header className="bg-white shadow-sm border-b border-gray-200 px-6 py-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">{pageTitle}</h2>
          <p className="text-gray-600 mt-1">{pageSubtitle}</p>
        </div>
        <div className="flex items-center space-x-4">
          {/* Notification Bell */}
          <Button
            variant="ghost"
            size="sm"
            className="relative p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100"
          >
            <Bell className="w-5 h-5" />
            <Badge 
              variant="destructive" 
              className="absolute -top-1 -right-1 w-5 h-5 text-xs p-0 flex items-center justify-center"
            >
              2
            </Badge>
          </Button>
          
          {/* Date Range Picker */}
          <div className="flex items-center space-x-2 bg-gray-50 px-3 py-2 rounded-lg border">
            <Calendar className="w-4 h-4 text-gray-500" />
            <span className="text-sm text-gray-700">Last 30 days</span>
            <ChevronDown className="w-3 h-3 text-gray-400" />
          </div>
        </div>
      </div>
    </header>
  );
}
