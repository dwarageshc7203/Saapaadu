import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';

const data = [
  { month: 'Jun', foodRescued: 2.1, co2Reduced: 6.3 },
  { month: 'Jul', foodRescued: 5.8, co2Reduced: 17.4 },
  { month: 'Aug', foodRescued: 9.2, co2Reduced: 27.6 },
  { month: 'Sep', foodRescued: 14.5, co2Reduced: 43.5 },
  { month: 'Oct', foodRescued: 18.9, co2Reduced: 56.7 },
  { month: 'Nov', foodRescued: 23.4, co2Reduced: 67.2 },
];

export function ImpactChart() {
  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Environmental Impact</CardTitle>
          <div className="text-sm text-gray-600">Last 6 months</div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={data}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f3f4f6" />
              <XAxis 
                dataKey="month" 
                stroke="#6b7280"
                fontSize={12}
              />
              <YAxis 
                stroke="#6b7280"
                fontSize={12}
              />
              <Tooltip />
              <Legend />
              <Area
                type="monotone"
                dataKey="foodRescued"
                stackId="1"
                stroke="#10b981"
                fill="rgba(16, 185, 129, 0.1)"
                name="Food Rescued (kg)"
              />
              <Area
                type="monotone"
                dataKey="co2Reduced"
                stackId="2"
                stroke="hsl(var(--primary))"
                fill="rgba(5, 150, 105, 0.1)"
                name="CO₂ Reduced (kg)"
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
}
