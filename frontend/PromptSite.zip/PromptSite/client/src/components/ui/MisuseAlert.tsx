import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { AlertTriangle, AlertCircle } from 'lucide-react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

interface MisuseAlertProps {
  alert: {
    id: number;
    alertType: string;
    description: string;
    riskLevel: 'low' | 'medium' | 'high' | 'critical';
    detectedAt: string;
  };
}

export function MisuseAlert({ alert }: MisuseAlertProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const updateAlertMutation = useMutation({
    mutationFn: async ({ action, status }: { action: string; status: string }) => {
      return apiRequest('POST', `/api/vendor/misuse-alerts/${alert.id}/action`, { action, status });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/vendor/misuse-alerts'] });
      toast({
        title: "Alert Updated",
        description: "The misuse alert has been updated successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update the alert. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleRestrict = () => {
    updateAlertMutation.mutate({ action: 'Access restricted for suspicious activity', status: 'resolved' });
  };

  const handleReview = () => {
    updateAlertMutation.mutate({ action: 'Flagged for manual review', status: 'reviewed' });
  };

  const getRiskColor = (level: string) => {
    switch (level) {
      case 'critical': return 'border-red-500 bg-red-50';
      case 'high': return 'border-red-400 bg-red-50';
      case 'medium': return 'border-yellow-400 bg-yellow-50';
      default: return 'border-gray-300 bg-gray-50';
    }
  };

  const getRiskIcon = (level: string) => {
    if (level === 'critical' || level === 'high') {
      return <AlertTriangle className="w-4 h-4 text-red-600" />;
    }
    return <AlertCircle className="w-4 h-4 text-yellow-600" />;
  };

  const getRiskBadgeVariant = (level: string) => {
    switch (level) {
      case 'critical': return 'destructive';
      case 'high': return 'destructive';
      case 'medium': return 'secondary';
      default: return 'outline';
    }
  };

  return (
    <Card className={`${getRiskColor(alert.riskLevel)} border`}>
      <CardContent className="p-4">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <div className="flex items-center space-x-2">
              {getRiskIcon(alert.riskLevel)}
              <p className="font-medium text-gray-900">
                {alert.alertType === 'high_frequency' ? 'High Frequency Orders' : 
                 alert.alertType === 'reselling_pattern' ? 'Potential Reselling Activity' : 
                 'Suspicious Pattern Detected'}
              </p>
              <Badge variant={getRiskBadgeVariant(alert.riskLevel) as any}>
                {alert.riskLevel}
              </Badge>
            </div>
            <p className="text-sm text-gray-600 mt-1">{alert.description}</p>
            <p className="text-sm text-gray-500 mt-2">
              Detected: {new Date(alert.detectedAt).toLocaleString()}
            </p>
          </div>
          <div className="flex space-x-2 ml-4">
            {alert.riskLevel === 'critical' || alert.riskLevel === 'high' ? (
              <Button
                size="sm"
                variant="destructive"
                onClick={handleRestrict}
                disabled={updateAlertMutation.isPending}
              >
                Restrict Access
              </Button>
            ) : (
              <Button
                size="sm"
                variant="secondary"
                onClick={handleReview}
                disabled={updateAlertMutation.isPending}
              >
                Review
              </Button>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
