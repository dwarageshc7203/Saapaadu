import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Lightbulb, Brain } from 'lucide-react';

export function DemandForecast() {
  const { data: forecasts, isLoading } = useQuery({
    queryKey: ['/api/vendor/demand-forecasts'],
  });

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>AI-Powered Demand Forecasting</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center h-40">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  const getDemandLevel = (confidence: number) => {
    if (confidence >= 80) return { label: 'High Demand', variant: 'default' as const, color: 'bg-green-100 text-green-800' };
    if (confidence >= 60) return { label: 'Medium Demand', variant: 'secondary' as const, color: 'bg-yellow-100 text-yellow-800' };
    return { label: 'Low Demand', variant: 'destructive' as const, color: 'bg-red-100 text-red-800' };
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle>AI-Powered Demand Forecasting</CardTitle>
            <p className="text-sm text-gray-600 mt-1">Recommendations for tomorrow's preparation</p>
          </div>
          <div className="flex items-center space-x-2 text-sm text-gray-500">
            <Brain className="w-4 h-4 text-accent" />
            <span>ML Prediction</span>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {forecasts?.slice(0, 3).map((forecast: any) => {
            const demandLevel = getDemandLevel(parseFloat(forecast.confidence));
            
            return (
              <div key={forecast.id} className="border border-gray-200 rounded-lg p-4">
                <div className="flex items-center justify-between mb-3">
                  <h4 className="font-medium text-gray-900">{forecast.foodItemName}</h4>
                  <Badge className={demandLevel.color}>
                    {demandLevel.label}
                  </Badge>
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Recommended:</span>
                    <span className="font-medium">{forecast.predictedQuantity} portions</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Confidence:</span>
                    <span className={`font-medium ${
                      parseFloat(forecast.confidence) >= 80 ? 'text-green-600' :
                      parseFloat(forecast.confidence) >= 60 ? 'text-yellow-600' : 'text-red-600'
                    }`}>
                      {Math.round(parseFloat(forecast.confidence))}%
                    </span>
                  </div>
                  <Progress 
                    value={parseFloat(forecast.confidence)} 
                    className="w-full h-2"
                  />
                </div>
              </div>
            );
          })}
        </div>

        <div className="mt-6 p-4 bg-blue-50 rounded-lg border border-blue-200">
          <div className="flex items-start space-x-3">
            <Lightbulb className="w-5 h-5 text-blue-600 mt-1" />
            <div>
              <p className="font-medium text-blue-900">AI Insights</p>
              <p className="text-sm text-blue-700 mt-1">
                Based on weather forecast, festival calendar, and historical data, demand for comfort foods 
                is expected to increase. Consider preparing extra portions of popular items.
              </p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
