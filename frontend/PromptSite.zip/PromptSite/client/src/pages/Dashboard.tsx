import { useAuth } from '@/contexts/AuthContext';
import { useRole } from '@/contexts/RoleContext';
import { Sidebar } from '@/components/layout/Sidebar';
import { Header } from '@/components/layout/Header';
import { VendorDashboard } from '@/components/dashboard/VendorDashboard';
import { CustomerDashboard } from '@/components/dashboard/CustomerDashboard';

export default function Dashboard() {
  const { user } = useAuth();
  const { currentRole } = useRole();

  // For demo purposes, show based on current role
  // In production, you'd check user permissions here
  const showRole = user?.role === 'admin' ? currentRole : user?.role;

  return (
    <div className="min-h-screen flex bg-gray-50">
      <Sidebar />
      <main className="flex-1 ml-64">
        <Header />
        <div className="p-6">
          {showRole === 'vendor' ? <VendorDashboard /> : <CustomerDashboard />}
        </div>
      </main>
    </div>
  );
}
