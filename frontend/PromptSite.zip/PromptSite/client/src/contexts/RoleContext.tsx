import { createContext, useContext, useState, ReactNode } from 'react';
import { useAuth } from './AuthContext';

interface RoleContextType {
  currentRole: 'vendor' | 'customer';
  switchRole: () => void;
  canSwitchRole: boolean;
}

const RoleContext = createContext<RoleContextType | undefined>(undefined);

export function RoleProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  const [currentRole, setCurrentRole] = useState<'vendor' | 'customer'>('vendor');

  const switchRole = () => {
    setCurrentRole(currentRole === 'vendor' ? 'customer' : 'vendor');
  };

  const canSwitchRole = user?.role === 'admin' || false; // For demo purposes, admins can switch roles

  return (
    <RoleContext.Provider value={{ currentRole, switchRole, canSwitchRole }}>
      {children}
    </RoleContext.Provider>
  );
}

export function useRole() {
  const context = useContext(RoleContext);
  if (context === undefined) {
    throw new Error('useRole must be used within a RoleProvider');
  }
  return context;
}
