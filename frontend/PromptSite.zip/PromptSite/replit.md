# Saapaadu ML Analytics Platform

## Project Overview
A comprehensive ML analytics platform for Saapaadu that classifies customer behavior, predicts food demand, and provides detailed role-based analytics dashboards with business intelligence insights.

## Project Architecture

### ML Models
1. **Customer Behavior Classifier**: Detects misusing customers who only buy during reselling time
2. **Food Demand Predictor**: Predicts optimal food preparation quantities for next day
3. **Analytics Engine**: Comprehensive analytics for both vendors and customers

### Technology Stack
- **Frontend**: Streamlit (for rapid prototyping and integration)
- **Backend**: Python with pandas, scikit-learn, numpy
- **ML Libraries**: scikit-learn, pandas, numpy, matplotlib, seaborn, plotly
- **Data Storage**: JSON/CSV for demo (designed for easy database integration)
- **Authentication**: Simple role-based auth system compatible with main app

### Core Features

#### Vendor Analytics
- Sales analysis (daily, weekly, monthly, yearly)
- Waste management (food saved, wasted, wastage reduction)
- Customer insights (regular, reselling-only, mixed behavior)
- Misusing customer detection with restriction options

#### Customer Analytics
- Order history tracking
- Environmental impact (food saved)
- Money saved calculations (actual price - reselling price)

#### ML Capabilities
- Real-time customer behavior classification
- Predictive food demand modeling
- Pattern analysis for optimization

## User Preferences
- Stack compatibility with existing Saapaadu project
- Role-based authentication integration
- Real-time analytics and insights
- Easy integration capabilities

## Recent Changes
- Initial project setup (Aug 20, 2025)
- Comprehensive ML analytics platform design
- Streamlit-based interface for rapid development